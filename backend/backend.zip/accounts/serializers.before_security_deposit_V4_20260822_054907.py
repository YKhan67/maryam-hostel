# backend/accounts/serializers.py
import random
from datetime import date
from decimal import Decimal
from django.db import transaction
from rest_framework import serializers
from .models import User, ModulePermission
from fees.models import SecurityDeposit
from hostels.models import StudentProfile, StudentUtilityCharge


class ModulePermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModulePermission
        fields = '__all__'


class StudentUtilityChargeSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentUtilityCharge
        fields = ["id", "name", "amount", "is_active", "created_at", "updated_at"]
        read_only_fields = ["created_at", "updated_at"]
    
    def to_internal_value(self, data):
        result = super().to_internal_value(data)
        # Preserve the ID field for updates
        if isinstance(data, dict) and 'id' in data:
            result['id'] = data['id']
        return result


class StudentProfileShortSerializer(serializers.ModelSerializer):
    utilities = StudentUtilityChargeSerializer(many=True, required=False)
    hostel = serializers.PrimaryKeyRelatedField(read_only=True)
    bed = serializers.PrimaryKeyRelatedField(read_only=True)
    monthly_rent = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, allow_null=True)
    security_deposit = serializers.SerializerMethodField()
    def get_security_deposit(self, obj):
        security_deposit = getattr(obj, 'security_deposit', None)
        if security_deposit is None:
            return None
        return security_deposit.amount

    joined_on = serializers.DateField(required=False, allow_null=True)
    left_on = serializers.DateField(required=False, allow_null=True)

    class Meta:
        model = StudentProfile
        fields = [
            "id", "hostel", "bed",
            "mobile", "whatsapp", "guardian_name", "guardian_phone", "guardian_nic_number",
            "parent_name", "parent_phone", "parent_whatsapp", "parent_nic_number", "college_name",
            "nic_number", "nic_front_picture", "nic_back_picture", "profile_picture",
            "course", "year", "joined_on", "left_on", "is_active",
            "parent_link_token", "utilities", "monthly_rent", "security_deposit"
        ]
        read_only_fields = ["id", "hostel", "bed", "parent_link_token"]

    def validate(self, attrs):
        if not attrs:
            return attrs

        required_fields = [
            "mobile", "whatsapp", "guardian_name", "guardian_phone",
            "parent_phone", "parent_whatsapp", "college_name",
            "nic_number", "joined_on",
        ]

        for field_name in required_fields:
            value = attrs.get(field_name, getattr(self.instance, field_name, None) if self.instance else None)
            if value is None or (isinstance(value, str) and not value.strip()):
                raise serializers.ValidationError({field_name: f"{field_name.replace('_', ' ').title()} is required."})

        joined_on = attrs.get("joined_on", getattr(self.instance, "joined_on", None) if self.instance else None)
        left_on = attrs.get("left_on", getattr(self.instance, "left_on", None) if self.instance else None)
        if joined_on and left_on and left_on < joined_on:
            raise serializers.ValidationError({"left_on": "Left on must be on or after joined on."})

        return attrs


class UserSerializer(serializers.ModelSerializer):
    profile = StudentProfileShortSerializer(source="student_profile", read_only=True)
    hostel_name = serializers.CharField(source="hostel.name", read_only=True)
    parent_link_token = serializers.CharField(source="student_profile.parent_link_token", read_only=True)

    class Meta:
        model = User
        fields = [
            "id", "username", "first_name", "last_name", "email", 
            "role", "hostel", "hostel_name", "is_active", "profile", "parent_link_token"
        ]


class UserCreateUpdateSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False, allow_blank=True)
    profile = StudentProfileShortSerializer(required=False)
    profile_nic_front_picture = serializers.ImageField(write_only=True, required=False)
    profile_nic_back_picture = serializers.ImageField(write_only=True, required=False)
    profile_profile_picture = serializers.ImageField(write_only=True, required=False)

    class Meta:
        model = User
        fields = [
            "id", "username", "first_name", "last_name", "email", 
            "role", "hostel", "password", "is_active", "profile",
            "profile_nic_front_picture", "profile_nic_back_picture", "profile_profile_picture"
        ]
        extra_kwargs = {'username': {'required': False, 'allow_blank': True}}

    def generate_unique_username(self, validated_data):
        hostel_obj = validated_data.get('hostel')
        first_name = validated_data.get('first_name', 'U').upper()
        name_char = first_name[0] if first_name else 'U'
        prefix = hostel_obj.code[:3].upper() if hostel_obj else "MH"
        while True:
            candidate = f"{prefix}{name_char}{random.randint(1000, 9999)}"
            if not User.objects.filter(username=candidate).exists():
                return candidate

    def to_internal_value(self, data):
        """
        Safely normalize multipart/FormData values before DRF validation.

        Django QueryDict may expose repeated multipart fields as lists.
        DRF expects scalar values for username, role, hostel, etc.
        """
        import json
        from decimal import Decimal as DecimalType

        if hasattr(data, "getlist"):
            normalized = {}

            for key in data.keys():
                values = data.getlist(key)

                if len(values) == 1:
                    normalized[key] = values[0]
                else:
                    normalized[key] = values

            data = normalized
        else:
            data = dict(data)

        # Normalize scalar fields.
        scalar_fields = (
            "username",
            "first_name",
            "last_name",
            "email",
            "role",
            "hostel",
            "password",
        )

        for key in scalar_fields:
            value = data.get(key)

            if isinstance(value, (list, tuple)):
                data[key] = value[0] if value else ""

        # Normalize boolean.
        if "is_active" in data:
            value = data["is_active"]

            if isinstance(value, (list, tuple)):
                value = value[0] if value else ""

            if isinstance(value, str):
                lowered = value.strip().lower()

                if lowered == "true":
                    data["is_active"] = True
                elif lowered == "false":
                    data["is_active"] = False

        # Parse profile JSON.
        if "profile" in data:
            profile = data["profile"]

            if isinstance(profile, (list, tuple)):
                profile = profile[0] if profile else {}

            if isinstance(profile, str):
                try:
                    profile = json.loads(profile)
                except (json.JSONDecodeError, TypeError):
                    profile = {}

            if not isinstance(profile, dict):
                profile = {}

            # Decimal normalization.
            for key in ("monthly_rent", "security_deposit"):
                if profile.get(key) in ("", None):
                    profile[key] = None
                elif key in profile:
                    try:
                        profile[key] = DecimalType(str(profile[key]))
                    except (TypeError, ValueError):
                        profile[key] = None

            # Utilities must remain a list.
            utilities = profile.get("utilities", [])

            if utilities is None:
                utilities = []

            elif isinstance(utilities, dict):
                utilities = [utilities]

            elif not isinstance(utilities, list):
                utilities = []

            profile["utilities"] = utilities
            data["profile"] = profile

        return super().to_internal_value(data)
    def validate(self, attrs):
        role = attrs.get("role", getattr(self.instance, "role", None))
        hostel = attrs.get("hostel", getattr(self.instance, "hostel", None))
        if role == "STUDENT" and hostel is None:
            raise serializers.ValidationError({"hostel": "Hostel is required for students."})

        profile_data = attrs.get("profile")
        if profile_data is not None and role == "STUDENT":
            profile_serializer = StudentProfileShortSerializer(data=profile_data)
            profile_serializer.is_valid(raise_exception=True)

        return attrs

    def _sync_student_utilities(self, profile, utilities_data):
        if utilities_data is None:
            return

        existing = {u.id: u for u in profile.utilities.all()}
        incoming_ids = []
        for utility_data in utilities_data:
            if not isinstance(utility_data, dict):
                continue
            payload = {key: value for key, value in utility_data.items() if key not in {"id"}}
            if not payload.get("name") and payload.get("amount") is None:
                continue

            utility_id = utility_data.get("id")
            utility = None
            # Only update if ID is explicitly provided
            if utility_id and utility_id in existing:
                utility = existing[utility_id]

            if utility is not None:
                for field, value in payload.items():
                    setattr(utility, field, value)
                utility.save()
                incoming_ids.append(utility.id)
            else:
                # Create new utility only if no ID was provided
                utility = StudentUtilityCharge.objects.create(student=profile, **payload)
                incoming_ids.append(utility.id)

        for utility in profile.utilities.exclude(id__in=incoming_ids):
            utility.is_active = False
            utility.save()

    def create(self, validated_data):
        profile_data = validated_data.pop("profile", None)
        raw_password = validated_data.pop("password", None)
        nic_front = validated_data.pop("profile_nic_front_picture", None)
        nic_back = validated_data.pop("profile_nic_back_picture", None)
        profile_pic = validated_data.pop("profile_profile_picture", None)

        if not validated_data.get('username'):
            validated_data['username'] = self.generate_unique_username(validated_data)

        with transaction.atomic():
            user = User.objects.create(**validated_data)
            if raw_password:
                user.set_password(raw_password)
                user.save()

            if profile_data and user.role == "STUDENT":
                security_deposit_value = profile_data.pop("security_deposit", None)
                profile_model_fields = {field.name for field in StudentProfile._meta.get_fields() if hasattr(StudentProfile, field.name)}
                student_defaults = {
                    key: value for key, value in profile_data.items()
                    if key in profile_model_fields and key != "utilities"
                }
                if nic_front:
                    student_defaults["nic_front_picture"] = nic_front
                if nic_back:
                    student_defaults["nic_back_picture"] = nic_back
                if profile_pic:
                    student_defaults["profile_picture"] = profile_pic
                if getattr(user, "hostel", None):
                    student_defaults.setdefault("hostel", user.hostel)
                profile = getattr(user, "student_profile", None)
                if profile is None:
                    profile = StudentProfile.objects.create(user=user, **student_defaults)
                for attr, value in student_defaults.items():
                    setattr(profile, attr, value)
                self._sync_student_utilities(profile, profile_data.get("utilities"))
                profile.save()

                # SecurityDeposit is a separate model and must be saved
                # only after StudentProfile exists.
                if security_deposit_value not in (None, ""):
                    deposit_amount = Decimal(str(security_deposit_value))

                    deposit_obj, _ = SecurityDeposit.objects.get_or_create(
                        student=profile,
                        defaults={
                            "amount": deposit_amount,
                            "date_paid": date.today(),
                        },
                    )

                    deposit_obj.amount = deposit_amount

                    if not deposit_obj.date_paid:
                        deposit_obj.date_paid = date.today()

                    deposit_obj.save(update_fields=["amount", "date_paid"])

            if profile_data and hasattr(user, "employee_profile"):
                for attr, value in profile_data.items():
                    if attr == "utilities":
                        continue
                    setattr(user.employee_profile, attr, value)
                user.employee_profile.save()

        return user

    def update(self, instance, validated_data):
        profile_data = validated_data.pop("profile", None)
        raw_password = validated_data.pop("password", None)
        nic_front = validated_data.pop("profile_nic_front_picture", None)
        nic_back = validated_data.pop("profile_nic_back_picture", None)
        profile_pic = validated_data.pop("profile_profile_picture", None)

        with transaction.atomic():
            for attr, value in validated_data.items():
                setattr(instance, attr, value)

            if raw_password:
                instance.set_password(raw_password)

            instance.save()

            if profile_data:
                if instance.role == "STUDENT":
                    # The nested serializer exposes security_deposit as a
                    # writable input field. Remove it from StudentProfile
                    # data because it is stored in SecurityDeposit.
                    security_deposit_value = profile_data.pop(
                        "security_deposit", None
                    )

                    # Always resolve the student's actual profile here.
                    profile = getattr(instance, "student_profile", None)

                    if profile is None:
                        profile = StudentProfile.objects.get(user=instance)

                    # Save normal StudentProfile fields first.
                    for attr, value in profile_data.items():
                        if attr == "utilities":
                            continue
                        setattr(profile, attr, value)

                    self._sync_student_utilities(
                        profile,
                        profile_data.get("utilities")
                    )

                    profile.save()

                    # Persist SecurityDeposit separately.
                    if security_deposit_value not in (None, ""):
                        deposit_amount = Decimal(
                            str(security_deposit_value)
                        )

                        deposit_obj, created = (
                            SecurityDeposit.objects.get_or_create(
                                student=profile,
                                defaults={
                                    "amount": deposit_amount,
                                    "date_paid": date.today(),
                                },
                            )
                        )

                        deposit_obj.amount = deposit_amount

                        if not deposit_obj.date_paid:
                            deposit_obj.date_paid = date.today()

                        deposit_obj.save(
                            update_fields=["amount", "date_paid"]
                        )

                elif hasattr(instance, "employee_profile"):
                    for attr, value in profile_data.items():
                        if attr == "utilities":
                            continue
                        setattr(instance.employee_profile, attr, value)

                    instance.employee_profile.save()

        return instance


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate_old_password(self, value):
        user = self.context['request'].user
        if not user.check_password(value):
            raise serializers.ValidationError("Incorrect current password")
        return value