import React, { useEffect, useState, useMemo } from "react";
import api from "../api";

const ROLE_OPTIONS = ["STUDENT", "HOSTEL_MANAGER", "CITY_MANAGER", "STAFF", "SUPER_ADMIN", "PARTNER"];

export default function UserManagementPage() {
  const [users, setUsers] = useState([]);
  const [hostels, setHostels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [branchFilter, setBranchFilter] = useState("ALL");
  const [editingUser, setEditingUser] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    setLoading(true);
    try {
      const [uRes, hRes] = await Promise.all([api.get("users/"), api.get("hostels/")]);
      setUsers(uRes.data.results || uRes.data);
      setHostels(hRes.data.results || hRes.data);
    } catch (err) { console.error("Sync failed:", err); }
    finally { setLoading(false); }
  }

  const filteredUsers = useMemo(() => {
    return users.filter(u => {
      const q = search.toLowerCase();
      const matchesSearch = !search || [u.username, u.first_name, u.last_name].some(v => v?.toLowerCase().includes(q));
      const matchesRole = roleFilter === "ALL" || u.role === roleFilter;
      const matchesBranch = branchFilter === "ALL" || String(u.hostel) === String(branchFilter);
      return matchesSearch && matchesRole && matchesBranch;
    });
  }, [users, search, roleFilter, branchFilter]);

  async function handleToggleStatus(user) {
    try {
      await api.post(`users/${user.id}/toggle_status/`);
      loadData();
    } catch (err) { alert(`Action failed: ${err.response?.status}`); }
  }

  async function handleResetPassword(user) {
    const p = prompt(`New temporary password for ${user.username}:`);
    if (!p) return;
    try {
      await api.post(`users/${user.id}/reset_password/`, { new_password: p });
      alert("Password updated successfully!");
    } catch (err) { alert("Failed to reset password."); }
  }

  if (loading) return <p>Syncing...</p>;

  return (
    <div className="page management-page">
        <div className="cards-row" style={{ marginBottom: '24px' }}>
          <div className="card kpi-card"><div className="card-title">All Accounts</div><div className="card-value">{users.length}</div><div className="card-subtext">Registered identities</div></div>
          <div className="card kpi-card"><div className="card-title">Students</div><div className="card-value">{users.filter(u => u.role === 'STUDENT').length}</div><div className="card-subtext">Active residents</div></div>
          <div className="card kpi-card"><div className="card-title">Status: Active</div><div className="card-value">{users.filter(u => u.is_active).length}</div><div className="card-subtext">Enabled accounts</div></div>
        </div>

        <div className="card filters-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
            <div style={{ display: 'flex', gap: '10px', flex: 1 }}>
              <input className="filter-input" style={{ flex: 1 }} placeholder="Search name or user..." value={search} onChange={e => setSearch(e.target.value)} />
              <select className="filter-select" value={roleFilter} onChange={e => setRoleFilter(e.target.value)}><option value="ALL">All Roles</option>{ROLE_OPTIONS.map(r => <option key={r} value={r}>{r}</option>)}</select>
              <select className="filter-select" value={branchFilter} onChange={e => setBranchFilter(e.target.value)}><option value="ALL">All Branches</option>{hostels.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}</select>
            </div>
            <button onClick={() => setShowAddModal(true)} className="btn btn-primary">➕ Create New User</button>
          </div>
        </div>

        <div className="card table-card" style={{ padding: 0 }}>
          <div className="table-wrapper">
            <table className="table">
              <thead><tr><th>Account</th><th>Contact Details</th><th>Primary Branch</th><th>Security Status</th><th style={{ textAlign: 'right', paddingRight: '24px' }}>Control Panel</th></tr></thead>
              <tbody>
                {filteredUsers.map(u => (
                  <tr key={u.id}>
                    <td><b>{u.username}</b><br/><span className="badge badge-soft">{u.role}</span></td>
                    <td>{u.first_name} {u.last_name}<br/><small>{u.email || "No email"}</small></td>
                    <td>{u.hostel_name || 'Global Access'}</td>
                    <td><span className={`badge ${u.is_active ? 'badge-success' : 'badge-danger'}`}>{u.is_active ? 'ACTIVE' : 'DISABLED'}</span></td>
                    <td style={{ textAlign: 'right', paddingRight: '24px' }}><div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}><button onClick={() => { setEditingUser(u); setShowEditModal(true); }} className="btn btn-soft" style={{ fontSize: '0.75rem' }}>Edit</button><button onClick={() => handleToggleStatus(u)} className="btn btn-soft" style={{ fontSize: '0.75rem' }}>Toggle</button><button onClick={() => handleResetPassword(u)} className="btn btn-soft" style={{ fontSize: '0.75rem' }}>Pass</button>{u.role === "STUDENT" && u.parent_link_token && (<button onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/parent-portal/${u.parent_link_token}`); alert("Link Copied!"); }} className="btn btn-soft" style={{ fontSize: '0.75rem' }}>🔗 Link</button>)}</div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {(showEditModal || showAddModal) && (
          <div className="modal-overlay" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(15, 23, 42, 0.7)', backdropFilter: 'blur(4px)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 }}>
            <div className="card" style={{ width: '95%', maxWidth: '800px', maxHeight: '90vh', overflowY: 'auto', padding: '32px', border: '1px solid #e2e8f0' }}>
              <h2 style={{ marginBottom: '24px' }}>{showAddModal ? "New User Registration" : `Modify Profile: ${editingUser.username}`}</h2>
              <UserEditForm user={showAddModal ? null : editingUser} hostels={hostels} onSave={() => { setShowEditModal(false); setShowAddModal(false); loadData(); }} onCancel={() => { setShowEditModal(false); setShowAddModal(false); }} />
            </div>
          </div>
        )}
    </div>
  );
}

function UtilityChargesUI({ utilities = [], onChange }) {
  const [rows, setRows] = useState(utilities.map((u, idx) => ({ 
    id: u.id,
    _key: u.id || `new_${idx}`, 
    name: u.name, 
    amount: u.amount, 
    is_active: u.is_active 
  })) || []);

  useEffect(() => {
    // Send utilities with ID preserved for backend updates
    onChange(rows.filter(r => r.name || r.amount));
  }, [rows, onChange]);

  const addUtility = () => {
    setRows([...rows, { _key: `new_${Date.now()}`, name: "", amount: "0.00", is_active: true }]);
  };

  const removeUtility = (key) => {
    setRows(rows.filter(r => r._key !== key));
  };

  const updateUtility = (key, field, value) => {
    setRows(rows.map(r => r._key === key ? { ...r, [field]: value } : r));
  };

  return (
    <div style={{ padding: '24px', background: '#f8fafc', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
      <h4 style={{ margin: '0 0 16px 0' }}>Utility Charges</h4>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {rows.map((row) => (
          <div key={row._key} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr auto', gap: '8px', alignItems: 'center' }}>
            <input className="form-input" placeholder="Utility (e.g., Heater, AC, Water)" value={row.name} onChange={(e) => updateUtility(row._key, 'name', e.target.value)} />
            <input className="form-input" type="number" placeholder="Amount" step="0.01" value={row.amount} onChange={(e) => updateUtility(row._key, 'amount', e.target.value)} />
            <button type="button" onClick={() => removeUtility(row._key)} className="btn btn-soft" style={{ padding: '8px 12px', fontSize: '0.75rem', background: '#fee2e2', color: '#dc2626' }}>Remove</button>
          </div>
        ))}
        <button type="button" onClick={addUtility} className="btn btn-soft" style={{ marginTop: '8px', fontWeight: 600 }}>+ Add Utility</button>
      </div>
    </div>
  );
}

function UserEditForm({ user, hostels, onSave, onCancel }) {
  const [form, setForm] = useState({
    username: user?.username || "",
    first_name: user?.first_name || "",
    last_name: user?.last_name || "",
    email: user?.email || "",
    role: user?.role || "STUDENT",
    hostel: user?.hostel || "",
    is_active: user ? user.is_active : true,
    password: "",
    profile: {
      mobile: user?.profile?.mobile || "",
      whatsapp: user?.profile?.whatsapp || "",
      guardian_name: user?.profile?.guardian_name || "",
      guardian_phone: user?.profile?.guardian_phone || "",
      guardian_nic_number: user?.profile?.guardian_nic_number || "",
      parent_name: user?.profile?.parent_name || "",
      parent_phone: user?.profile?.parent_phone || "",
      parent_whatsapp: user?.profile?.parent_whatsapp || "",
      parent_nic_number: user?.profile?.parent_nic_number || "",
      college_name: user?.profile?.college_name || "",
      nic_number: user?.profile?.nic_number || "",
      joined_on: user?.profile?.joined_on || "",
      monthly_rent: user?.profile?.monthly_rent ?? "",
      course: user?.profile?.course || "",
      year: user?.profile?.year || "",
      left_on: user?.profile?.left_on || "",
      security_deposit: user?.profile?.security_deposit ?? "",
      utilities: user?.profile?.utilities || []
    }
  });

  const [imageFiles, setImageFiles] = useState({
    nic_front_picture: null,
    nic_back_picture: null,
    profile_picture: null
  });

  const [utilities, setUtilities] = useState(user?.profile?.utilities || []);

  const handleImageChange = (e, field) => {
    setImageFiles({ ...imageFiles, [field]: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // ------------------------------------------------------------
      // Normalize all values before building FormData.
      // DRF expects scalar values for these fields, not arrays.
      // ------------------------------------------------------------

      const scalar = (value, fallback = "") => {
        if (Array.isArray(value)) {
          return value.length > 0 ? String(value[0] ?? fallback) : fallback;
        }
        if (value === null || value === undefined) {
          return fallback;
        }
        return String(value);
      };

      const scalarNumber = (value) => {
        if (Array.isArray(value)) {
          return value.length > 0 ? String(value[0]) : "";
        }
        if (value === null || value === undefined || value === "") {
          return "";
        }
        return String(value);
      };

      const scalarBoolean = (value) => {
        if (Array.isArray(value)) {
          value = value.length > 0 ? value[0] : false;
        }

        if (typeof value === "boolean") {
          return value ? "true" : "false";
        }

        if (value === "true" || value === "1") {
          return "true";
        }

        return "false";
      };

      // Make absolutely sure profile is an object.
      // This prevents sending profile: [...]
      const rawProfile = form.profile;

      const profileObject =
        rawProfile &&
        typeof rawProfile === "object" &&
        !Array.isArray(rawProfile)
          ? rawProfile
          : {};

      const profileData = {
        ...profileObject,
        utilities: Array.isArray(utilities) ? utilities : [],
      };

      // ------------------------------------------------------------
      // Build multipart FormData
      // ------------------------------------------------------------

      const formDataObj = new FormData();

      // User scalar fields
      formDataObj.append(
        "username",
        scalar(form.username)
      );

      formDataObj.append(
        "first_name",
        scalar(form.first_name)
      );

      formDataObj.append(
        "last_name",
        scalar(form.last_name)
      );

      formDataObj.append(
        "email",
        scalar(form.email)
      );

      // DRF ChoiceField -> "STUDENT", not ["STUDENT"]
      formDataObj.append(
        "role",
        scalar(form.role, "STUDENT")
      );

      // DRF BooleanField -> "true"/"false"
      formDataObj.append(
        "is_active",
        scalarBoolean(form.is_active)
      );

      // DRF PrimaryKeyRelatedField -> scalar PK, not [PK]
      const hostelValue = scalarNumber(form.hostel);

      if (hostelValue !== "") {
        formDataObj.append("hostel", hostelValue);
      }

      if (form.password) {
        formDataObj.append(
          "password",
          scalar(form.password)
        );
      }

      // Profile must be a JSON OBJECT, never an array.
      formDataObj.append(
        "profile",
        JSON.stringify(profileData)
      );

      // Append image files if selected
      if (imageFiles.nic_front_picture) formDataObj.append("profile_nic_front_picture", imageFiles.nic_front_picture);
      if (imageFiles.nic_back_picture) formDataObj.append("profile_nic_back_picture", imageFiles.nic_back_picture);
      if (imageFiles.profile_picture) formDataObj.append("profile_profile_picture", imageFiles.profile_picture);
      const endpoint = user ? `users/${user.id}/` : "users/";
      const method = user ? "PATCH" : "POST";
      const token = localStorage.getItem("accessToken");

      // Use fetch directly for FormData to avoid axios Content-Type interference
      const response = await fetch(`${api.defaults.baseURL}${endpoint}`, {
        method,
        headers: {
          Authorization: `Bearer ${token}`,
          // DO NOT set Content-Type - let browser set it with boundary
        },
        body: formDataObj,
      });

      if (!response.ok) {
        const errorData = await response.json();
        const httpError = new Error("Request failed");
        httpError.response = { data: errorData, status: response.status };
        throw httpError;
      }

      alert(user ? "Profile updated!" : "User created!");
      onSave();
    } catch (err) {
      const msg = err.response?.data ? JSON.stringify(err.response.data) : "Save failed.";
      alert(`Action failed: ${msg}`);
    }
  };
  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {form.role === 'STUDENT' ? (
        <>
          {/* Block 1: Basic & Personal Information */}
          <div style={{ padding: '24px', background: '#f8fafc', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h4 style={{ margin: '0 0 16px 0' }}>Block 1: Basic Information</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div className="form-group"><label className="form-label">Username</label><input className="form-input" placeholder="Auto-generate if blank" value={form.username} onChange={e => setForm({...form, username: e.target.value})} /></div>
              {!user && <div className="form-group"><label className="form-label">Password</label><input className="form-input" type="password" required value={form.password} onChange={e => setForm({...form, password: e.target.value})} /></div>}
              <div className="form-group"><label className="form-label">First Name</label><input className="form-input" value={form.first_name} onChange={e => setForm({...form, first_name: e.target.value})} /></div>
              <div className="form-group"><label className="form-label">Last Name</label><input className="form-input" value={form.last_name} onChange={e => setForm({...form, last_name: e.target.value})} /></div>
              <div className="form-group"><label className="form-label">Email</label><input className="form-input" type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} /></div>
              <div className="form-group"><label className="form-label">Role</label><select className="form-input" value={form.role} onChange={e => setForm({...form, role: e.target.value})}>{ROLE_OPTIONS.map(r => <option key={r} value={r}>{r}</option>)}</select></div>
              <div className="form-group"><label className="form-label">Branch</label><select className="form-input" value={form.hostel} onChange={e => setForm({...form, hostel: e.target.value})}><option value="">Global / Unassigned</option>{hostels.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}</select></div>
              <div className="form-group"><label className="form-label">NIC Number *</label><input className="form-input" required value={form.profile.nic_number} onChange={e => setForm({...form, profile: {...form.profile, nic_number: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Mobile *</label><input className="form-input" required value={form.profile.mobile} onChange={e => setForm({...form, profile: {...form.profile, mobile: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">WhatsApp *</label><input className="form-input" required value={form.profile.whatsapp} onChange={e => setForm({...form, profile: {...form.profile, whatsapp: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">College Name *</label><input className="form-input" required value={form.profile.college_name} onChange={e => setForm({...form, profile: {...form.profile, college_name: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Joined On *</label><input className="form-input" type="date" required value={form.profile.joined_on} onChange={e => setForm({...form, profile: {...form.profile, joined_on: e.target.value}})} /></div>
            </div>
          </div>

          {/* Block 2: Guardian & Parent Information */}
          <div style={{ padding: '24px', background: '#f8fafc', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h4 style={{ margin: '0 0 16px 0' }}>Block 2: Guardian & Parent Details</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div className="form-group"><label className="form-label">Guardian Name *</label><input className="form-input" required value={form.profile.guardian_name} onChange={e => setForm({...form, profile: {...form.profile, guardian_name: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Guardian Phone *</label><input className="form-input" required value={form.profile.guardian_phone} onChange={e => setForm({...form, profile: {...form.profile, guardian_phone: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Guardian NIC Number</label><input className="form-input" value={form.profile.guardian_nic_number} onChange={e => setForm({...form, profile: {...form.profile, guardian_nic_number: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Parent Name</label><input className="form-input" value={form.profile.parent_name} onChange={e => setForm({...form, profile: {...form.profile, parent_name: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Parent Phone *</label><input className="form-input" required value={form.profile.parent_phone} onChange={e => setForm({...form, profile: {...form.profile, parent_phone: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Parent WhatsApp *</label><input className="form-input" required value={form.profile.parent_whatsapp} onChange={e => setForm({...form, profile: {...form.profile, parent_whatsapp: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Parent NIC Number</label><input className="form-input" value={form.profile.parent_nic_number} onChange={e => setForm({...form, profile: {...form.profile, parent_nic_number: e.target.value}})} /></div>
            </div>
          </div>

          {/* Block 3: Academic Information */}
          <div style={{ padding: '24px', background: '#f8fafc', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h4 style={{ margin: '0 0 16px 0' }}>Block 3: Academic Information</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
              <div className="form-group"><label className="form-label">Course</label><input className="form-input" value={form.profile.course} onChange={e => setForm({...form, profile: {...form.profile, course: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Year</label><input className="form-input" value={form.profile.year} onChange={e => setForm({...form, profile: {...form.profile, year: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Left On</label><input className="form-input" type="date" value={form.profile.left_on} onChange={e => setForm({...form, profile: {...form.profile, left_on: e.target.value}})} /></div>
            </div>
          </div>

          {/* Block 4: Identification Documents */}
          <div style={{ padding: '24px', background: '#f8fafc', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h4 style={{ margin: '0 0 16px 0' }}>Block 4: Identification Documents</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
              <div className="form-group"><label className="form-label">NIC Front Picture</label><input type="file" accept="image/*" onChange={e => handleImageChange(e, 'nic_front_picture')} />{user?.profile?.nic_front_picture && <small style={{ color: '#666' }}>Current: Uploaded</small>}</div>
              <div className="form-group"><label className="form-label">NIC Back Picture</label><input type="file" accept="image/*" onChange={e => handleImageChange(e, 'nic_back_picture')} />{user?.profile?.nic_back_picture && <small style={{ color: '#666' }}>Current: Uploaded</small>}</div>
              <div className="form-group"><label className="form-label">Profile Picture</label><input type="file" accept="image/*" onChange={e => handleImageChange(e, 'profile_picture')} />{user?.profile?.profile_picture && <small style={{ color: '#666' }}>Current: Uploaded</small>}</div>
            </div>
          </div>

          {/* Block 5: Rent & Utilities */}
          <div style={{ padding: '24px', background: '#f8fafc', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h4 style={{ margin: '0 0 16px 0' }}>Block 5: Rent & Charges</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
              <div className="form-group"><label className="form-label">Monthly Rent</label><input className="form-input" type="number" step="0.01" value={form.profile.monthly_rent ?? ""} onChange={e => setForm({...form, profile: {...form.profile, monthly_rent: e.target.value}})} /></div>
              <div className="form-group"><label className="form-label">Security Deposit</label><input className="form-input" type="number" step="0.01" value={form.profile.security_deposit ?? ""} onChange={e => setForm({...form, profile: {...form.profile, security_deposit: e.target.value}})} /></div>
            </div>
            <UtilityChargesUI utilities={utilities} onChange={setUtilities} />
          </div>
        </>
      ) : (
        <>
          {/* Non-STUDENT role: Basic info only */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px' }}>
            <div className="form-group"><label className="form-label">Username</label><input className="form-input" placeholder="Auto-generate if blank" value={form.username} onChange={e => setForm({...form, username: e.target.value})} /></div>
            {!user && <div className="form-group"><label className="form-label">Password</label><input className="form-input" type="password" required value={form.password} onChange={e => setForm({...form, password: e.target.value})} /></div>}
            <div className="form-group"><label className="form-label">First Name</label><input className="form-input" value={form.first_name} onChange={e => setForm({...form, first_name: e.target.value})} /></div>
            <div className="form-group"><label className="form-label">Last Name</label><input className="form-input" value={form.last_name} onChange={e => setForm({...form, last_name: e.target.value})} /></div>
            <div className="form-group"><label className="form-label">Email</label><input className="form-input" type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} /></div>
            <div className="form-group"><label className="form-label">Role</label><select className="form-input" value={form.role} onChange={e => setForm({...form, role: e.target.value})}>{ROLE_OPTIONS.map(r => <option key={r} value={r}>{r}</option>)}</select></div>
            <div className="form-group"><label className="form-label">Branch</label><select className="form-input" value={form.hostel} onChange={e => setForm({...form, hostel: e.target.value})}><option value="">Global / Unassigned</option>{hostels.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}</select></div>
          </div>
        </>
      )}

      <div style={{ display: 'flex', gap: '12px' }}><button type="submit" className="btn btn-primary" style={{ flex: 1 }}>{user ? "Save" : "Create"}</button><button type="button" onClick={onCancel} className="btn btn-soft" style={{ flex: 1 }}>Cancel</button></div>
    </form>
  );
}